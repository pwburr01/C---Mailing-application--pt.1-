﻿//C7353
//CIS 200-01
//10-23-2017
//This class is for the letter form and adds a new letter to the system

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UPVApp
{
    public partial class LetterForm : Form
    {
        //creates list so that items can be added to it in the constructor
        private List<Address> _addresses;

        //precondition: button is clicked on to call the form
        //postcondition: form intializes and loads information needed
        public LetterForm(List<Address> addressList)
        {
            InitializeComponent();

            _addresses = addressList;

        }
        //precondition: form is initialized
        //postcondition: form is loaded with the correct information displayed
        private void LetterForm_Load(object sender, EventArgs e)
        {
            foreach (Address a in _addresses)
            {
                destCmbBx.Items.Add(a.Name);
                originCmbBx.Items.Add(a.Name);
            }
        }
        //precondition: combobox selected
        //postconditoin: index of address is created
        internal int LetterOrigin
        {
            get
            {
                return originCmbBx.SelectedIndex;
            }

            set
            {
                originCmbBx.SelectedIndex = value;
            }
        }
        //precondition: combobox selected
        //postconditoin: index of address is created
        internal int LetterDestination
        {
            get
            {
               return destCmbBx.SelectedIndex;
            }

            set
            {
                destCmbBx.SelectedIndex = value;
            }
        }
        //precondition: none
        //postcondition: letter price is created and validated
        internal Int32 LetterCost
        {
            get
            {
                return Convert.ToInt32(costTxtBx.Text);
            }

            set
            {
                int zipCode;
                bool result = Int32.TryParse(costTxtBx.Text, out zipCode);
                if (result)
                {
                    zipCode = value;
                }
                else
                {
                    costTxtBx.SelectAll();
                    errorProvider.SetError(costTxtBx, "Must be a number.");
                }

            }
        }
        //precondition: none
        //postcondition: closes form
        private void cnclBtn_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        //precondition: none
        //postcondition: validates correct fields and sends an okay back to original form for the information to be added.
        private void okBtn_Click(object sender, EventArgs e)
        {
            int zipCode;
            bool result = Int32.TryParse(costTxtBx.Text, out zipCode);
            if (result)
            {
               if(destCmbBx.Text != originCmbBx.Text)
                {
                    DialogResult = DialogResult.OK;
                    this.Close();
                }
                else
                {
                    destCmbBx.SelectAll();
                    errorProvider.SetError(destCmbBx, "Destination cannot be Origin of letter.");
                }
            }
            else
            {
                costTxtBx.SelectAll();
                errorProvider.SetError(costTxtBx, "Must be a number.");
            }
        }
    }
}
