﻿namespace UPVApp
{
    partial class AddressForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.nameLbl = new System.Windows.Forms.Label();
            this.addressLbl = new System.Windows.Forms.Label();
            this.cityLbl = new System.Windows.Forms.Label();
            this.stateLbl = new System.Windows.Forms.Label();
            this.zipLbl = new System.Windows.Forms.Label();
            this.nameTxtBx = new System.Windows.Forms.TextBox();
            this.address1TxtBx = new System.Windows.Forms.TextBox();
            this.address2TxtBx = new System.Windows.Forms.TextBox();
            this.cityTxtBx = new System.Windows.Forms.TextBox();
            this.zipTxtBx = new System.Windows.Forms.TextBox();
            this.stateCmbBx = new System.Windows.Forms.ComboBox();
            this.okBtn = new System.Windows.Forms.Button();
            this.cnclBtn = new System.Windows.Forms.Button();
            this.errorProvider = new System.Windows.Forms.ErrorProvider(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider)).BeginInit();
            this.SuspendLayout();
            // 
            // nameLbl
            // 
            this.nameLbl.AutoSize = true;
            this.nameLbl.Location = new System.Drawing.Point(48, 31);
            this.nameLbl.Name = "nameLbl";
            this.nameLbl.Size = new System.Drawing.Size(49, 17);
            this.nameLbl.TabIndex = 0;
            this.nameLbl.Text = "Name:";
            // 
            // addressLbl
            // 
            this.addressLbl.AutoSize = true;
            this.addressLbl.Location = new System.Drawing.Point(33, 62);
            this.addressLbl.Name = "addressLbl";
            this.addressLbl.Size = new System.Drawing.Size(64, 17);
            this.addressLbl.TabIndex = 1;
            this.addressLbl.Text = "Address:";
            // 
            // cityLbl
            // 
            this.cityLbl.AutoSize = true;
            this.cityLbl.Location = new System.Drawing.Point(65, 126);
            this.cityLbl.Name = "cityLbl";
            this.cityLbl.Size = new System.Drawing.Size(35, 17);
            this.cityLbl.TabIndex = 2;
            this.cityLbl.Text = "City:";
            // 
            // stateLbl
            // 
            this.stateLbl.AutoSize = true;
            this.stateLbl.Location = new System.Drawing.Point(52, 161);
            this.stateLbl.Name = "stateLbl";
            this.stateLbl.Size = new System.Drawing.Size(45, 17);
            this.stateLbl.TabIndex = 3;
            this.stateLbl.Text = "State:";
            // 
            // zipLbl
            // 
            this.zipLbl.AutoSize = true;
            this.zipLbl.Location = new System.Drawing.Point(65, 196);
            this.zipLbl.Name = "zipLbl";
            this.zipLbl.Size = new System.Drawing.Size(32, 17);
            this.zipLbl.TabIndex = 4;
            this.zipLbl.Text = "Zip:";
            // 
            // nameTxtBx
            // 
            this.nameTxtBx.Location = new System.Drawing.Point(115, 28);
            this.nameTxtBx.Name = "nameTxtBx";
            this.nameTxtBx.Size = new System.Drawing.Size(125, 22);
            this.nameTxtBx.TabIndex = 5;
            this.nameTxtBx.Validating += new System.ComponentModel.CancelEventHandler(this.nameTxtBx_Validating);
            this.nameTxtBx.Validated += new System.EventHandler(this.nameTxtBx_Validated);
            // 
            // address1TxtBx
            // 
            this.address1TxtBx.Location = new System.Drawing.Point(115, 62);
            this.address1TxtBx.Name = "address1TxtBx";
            this.address1TxtBx.Size = new System.Drawing.Size(125, 22);
            this.address1TxtBx.TabIndex = 6;
            this.address1TxtBx.Validating += new System.ComponentModel.CancelEventHandler(this.addressTxtBx_Validating);
            this.address1TxtBx.Validated += new System.EventHandler(this.addressTxtBx_Validated);
            // 
            // address2TxtBx
            // 
            this.address2TxtBx.Location = new System.Drawing.Point(115, 90);
            this.address2TxtBx.Name = "address2TxtBx";
            this.address2TxtBx.Size = new System.Drawing.Size(125, 22);
            this.address2TxtBx.TabIndex = 7;
            // 
            // cityTxtBx
            // 
            this.cityTxtBx.Location = new System.Drawing.Point(115, 123);
            this.cityTxtBx.Name = "cityTxtBx";
            this.cityTxtBx.Size = new System.Drawing.Size(125, 22);
            this.cityTxtBx.TabIndex = 8;
            this.cityTxtBx.Validating += new System.ComponentModel.CancelEventHandler(this.cityTxtBx_Validating);
            this.cityTxtBx.Validated += new System.EventHandler(this.cityTxtBx_Validated);
            // 
            // zipTxtBx
            // 
            this.zipTxtBx.Location = new System.Drawing.Point(115, 193);
            this.zipTxtBx.MaxLength = 5;
            this.zipTxtBx.Name = "zipTxtBx";
            this.zipTxtBx.Size = new System.Drawing.Size(125, 22);
            this.zipTxtBx.TabIndex = 9;
            this.zipTxtBx.Validating += new System.ComponentModel.CancelEventHandler(this.zipTxtBx_Validating);
            this.zipTxtBx.Validated += new System.EventHandler(this.zipTxtBx_Validated);
            // 
            // stateCmbBx
            // 
            this.stateCmbBx.FormattingEnabled = true;
            this.stateCmbBx.Location = new System.Drawing.Point(115, 158);
            this.stateCmbBx.Name = "stateCmbBx";
            this.stateCmbBx.Size = new System.Drawing.Size(124, 24);
            this.stateCmbBx.TabIndex = 10;
            this.stateCmbBx.Text = "KY";
            // 
            // okBtn
            // 
            this.okBtn.Location = new System.Drawing.Point(23, 250);
            this.okBtn.Name = "okBtn";
            this.okBtn.Size = new System.Drawing.Size(77, 31);
            this.okBtn.TabIndex = 11;
            this.okBtn.Text = "OK";
            this.okBtn.UseVisualStyleBackColor = true;
            this.okBtn.Click += new System.EventHandler(this.okBtn_Click);
            // 
            // cnclBtn
            // 
            this.cnclBtn.Location = new System.Drawing.Point(162, 250);
            this.cnclBtn.Name = "cnclBtn";
            this.cnclBtn.Size = new System.Drawing.Size(77, 31);
            this.cnclBtn.TabIndex = 12;
            this.cnclBtn.Text = "Cancel";
            this.cnclBtn.UseVisualStyleBackColor = true;
            this.cnclBtn.Click += new System.EventHandler(this.cnclBtn_Click);
            // 
            // errorProvider
            // 
            this.errorProvider.ContainerControl = this;
            // 
            // AddressForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(281, 293);
            this.Controls.Add(this.cnclBtn);
            this.Controls.Add(this.okBtn);
            this.Controls.Add(this.stateCmbBx);
            this.Controls.Add(this.zipTxtBx);
            this.Controls.Add(this.cityTxtBx);
            this.Controls.Add(this.address2TxtBx);
            this.Controls.Add(this.address1TxtBx);
            this.Controls.Add(this.nameTxtBx);
            this.Controls.Add(this.zipLbl);
            this.Controls.Add(this.stateLbl);
            this.Controls.Add(this.cityLbl);
            this.Controls.Add(this.addressLbl);
            this.Controls.Add(this.nameLbl);
            this.Name = "AddressForm";
            this.Text = "Address";
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label nameLbl;
        private System.Windows.Forms.Label addressLbl;
        private System.Windows.Forms.Label cityLbl;
        private System.Windows.Forms.Label stateLbl;
        private System.Windows.Forms.Label zipLbl;
        private System.Windows.Forms.TextBox nameTxtBx;
        private System.Windows.Forms.TextBox address1TxtBx;
        private System.Windows.Forms.TextBox address2TxtBx;
        private System.Windows.Forms.TextBox cityTxtBx;
        private System.Windows.Forms.TextBox zipTxtBx;
        private System.Windows.Forms.ComboBox stateCmbBx;
        private System.Windows.Forms.Button okBtn;
        private System.Windows.Forms.Button cnclBtn;
        private System.Windows.Forms.ErrorProvider errorProvider;
    }
}