﻿namespace UPVApp
{
    partial class Prog2Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStrip = new System.Windows.Forms.ToolStripMenuItem();
            this.insertToolStrip = new System.Windows.Forms.ToolStripMenuItem();
            this.reportToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.abtMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addressMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.letterMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.listAddMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.listParcelMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.displayLstBx = new System.Windows.Forms.ListBox();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStrip,
            this.insertToolStrip,
            this.reportToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(772, 28);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStrip
            // 
            this.fileToolStrip.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.abtMenuItem,
            this.exitMenuItem});
            this.fileToolStrip.Name = "fileToolStrip";
            this.fileToolStrip.Size = new System.Drawing.Size(44, 24);
            this.fileToolStrip.Text = "File";
            // 
            // insertToolStrip
            // 
            this.insertToolStrip.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addressMenuItem,
            this.letterMenuItem});
            this.insertToolStrip.Name = "insertToolStrip";
            this.insertToolStrip.Size = new System.Drawing.Size(57, 24);
            this.insertToolStrip.Text = "Insert";
            // 
            // reportToolStripMenuItem
            // 
            this.reportToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.listAddMenuItem,
            this.listParcelMenuItem});
            this.reportToolStripMenuItem.Name = "reportToolStripMenuItem";
            this.reportToolStripMenuItem.Size = new System.Drawing.Size(66, 24);
            this.reportToolStripMenuItem.Text = "Report";
            // 
            // abtMenuItem
            // 
            this.abtMenuItem.Name = "abtMenuItem";
            this.abtMenuItem.Size = new System.Drawing.Size(181, 26);
            this.abtMenuItem.Text = "About";
            this.abtMenuItem.Click += new System.EventHandler(this.abtMenuItem_Click);
            // 
            // exitMenuItem
            // 
            this.exitMenuItem.Name = "exitMenuItem";
            this.exitMenuItem.Size = new System.Drawing.Size(181, 26);
            this.exitMenuItem.Text = "Exit";
            this.exitMenuItem.Click += new System.EventHandler(this.exitMenuItem_Click);
            // 
            // addressMenuItem
            // 
            this.addressMenuItem.Name = "addressMenuItem";
            this.addressMenuItem.Size = new System.Drawing.Size(181, 26);
            this.addressMenuItem.Text = "Address";
            this.addressMenuItem.Click += new System.EventHandler(this.addressMenuItem_Click);
            // 
            // letterMenuItem
            // 
            this.letterMenuItem.Name = "letterMenuItem";
            this.letterMenuItem.Size = new System.Drawing.Size(181, 26);
            this.letterMenuItem.Text = "Letter";
            this.letterMenuItem.Click += new System.EventHandler(this.letterMenuItem_Click);
            // 
            // listAddMenuItem
            // 
            this.listAddMenuItem.Name = "listAddMenuItem";
            this.listAddMenuItem.Size = new System.Drawing.Size(181, 26);
            this.listAddMenuItem.Text = "List Addresses";
            this.listAddMenuItem.Click += new System.EventHandler(this.listAddMenuItem_Click);
            // 
            // listParcelMenuItem
            // 
            this.listParcelMenuItem.Name = "listParcelMenuItem";
            this.listParcelMenuItem.Size = new System.Drawing.Size(181, 26);
            this.listParcelMenuItem.Text = "List Parcels";
            this.listParcelMenuItem.Click += new System.EventHandler(this.listParcelMenuItem_Click);
            // 
            // displayLstBx
            // 
            this.displayLstBx.ItemHeight = 16;
            this.displayLstBx.Location = new System.Drawing.Point(6, 41);
            this.displayLstBx.Name = "displayLstBx";
            this.displayLstBx.SelectionMode = System.Windows.Forms.SelectionMode.None;
            this.displayLstBx.Size = new System.Drawing.Size(756, 420);
            this.displayLstBx.TabIndex = 1;
            // 
            // Prog2Form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(772, 471);
            this.Controls.Add(this.displayLstBx);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Prog2Form";
            this.Text = "Program 2";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStrip;
        private System.Windows.Forms.ToolStripMenuItem insertToolStrip;
        private System.Windows.Forms.ToolStripMenuItem reportToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem abtMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addressMenuItem;
        private System.Windows.Forms.ToolStripMenuItem letterMenuItem;
        private System.Windows.Forms.ToolStripMenuItem listAddMenuItem;
        private System.Windows.Forms.ToolStripMenuItem listParcelMenuItem;
        private System.Windows.Forms.ListBox displayLstBx;
    }
}

