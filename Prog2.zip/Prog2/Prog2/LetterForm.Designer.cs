﻿namespace UPVApp
{
    partial class LetterForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.okBtn = new System.Windows.Forms.Button();
            this.cnclBtn = new System.Windows.Forms.Button();
            this.originCmbBx = new System.Windows.Forms.ComboBox();
            this.destCmbBx = new System.Windows.Forms.ComboBox();
            this.costTxtBx = new System.Windows.Forms.TextBox();
            this.originLbl = new System.Windows.Forms.Label();
            this.destinationLbl = new System.Windows.Forms.Label();
            this.costLbl = new System.Windows.Forms.Label();
            this.errorProvider = new System.Windows.Forms.ErrorProvider(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider)).BeginInit();
            this.SuspendLayout();
            // 
            // okBtn
            // 
            this.okBtn.Location = new System.Drawing.Point(25, 164);
            this.okBtn.Name = "okBtn";
            this.okBtn.Size = new System.Drawing.Size(117, 25);
            this.okBtn.TabIndex = 0;
            this.okBtn.Text = "OK";
            this.okBtn.UseVisualStyleBackColor = true;
            this.okBtn.Click += new System.EventHandler(this.okBtn_Click);
            // 
            // cnclBtn
            // 
            this.cnclBtn.Location = new System.Drawing.Point(236, 164);
            this.cnclBtn.Name = "cnclBtn";
            this.cnclBtn.Size = new System.Drawing.Size(117, 25);
            this.cnclBtn.TabIndex = 1;
            this.cnclBtn.Text = "Cancel";
            this.cnclBtn.UseVisualStyleBackColor = true;
            this.cnclBtn.Click += new System.EventHandler(this.cnclBtn_Click);
            // 
            // originCmbBx
            // 
            this.originCmbBx.FormattingEnabled = true;
            this.originCmbBx.Location = new System.Drawing.Point(167, 29);
            this.originCmbBx.Name = "originCmbBx";
            this.originCmbBx.Size = new System.Drawing.Size(151, 24);
            this.originCmbBx.TabIndex = 2;
            // 
            // destCmbBx
            // 
            this.destCmbBx.FormattingEnabled = true;
            this.destCmbBx.Location = new System.Drawing.Point(167, 70);
            this.destCmbBx.Name = "destCmbBx";
            this.destCmbBx.Size = new System.Drawing.Size(151, 24);
            this.destCmbBx.TabIndex = 3;
            // 
            // costTxtBx
            // 
            this.costTxtBx.Location = new System.Drawing.Point(167, 112);
            this.costTxtBx.Name = "costTxtBx";
            this.costTxtBx.Size = new System.Drawing.Size(151, 22);
            this.costTxtBx.TabIndex = 4;
            // 
            // originLbl
            // 
            this.originLbl.AutoSize = true;
            this.originLbl.Location = new System.Drawing.Point(55, 32);
            this.originLbl.Name = "originLbl";
            this.originLbl.Size = new System.Drawing.Size(106, 17);
            this.originLbl.TabIndex = 5;
            this.originLbl.Text = "Origin Address:";
            // 
            // destinationLbl
            // 
            this.destinationLbl.AutoSize = true;
            this.destinationLbl.Location = new System.Drawing.Point(22, 73);
            this.destinationLbl.Name = "destinationLbl";
            this.destinationLbl.Size = new System.Drawing.Size(139, 17);
            this.destinationLbl.TabIndex = 6;
            this.destinationLbl.Text = "Destination Address:";
            // 
            // costLbl
            // 
            this.costLbl.AutoSize = true;
            this.costLbl.Location = new System.Drawing.Point(84, 115);
            this.costLbl.Name = "costLbl";
            this.costLbl.Size = new System.Drawing.Size(77, 17);
            this.costLbl.TabIndex = 7;
            this.costLbl.Text = "Fixed Cost:";
            // 
            // errorProvider
            // 
            this.errorProvider.ContainerControl = this;
            // 
            // LetterForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(397, 208);
            this.Controls.Add(this.costLbl);
            this.Controls.Add(this.destinationLbl);
            this.Controls.Add(this.originLbl);
            this.Controls.Add(this.costTxtBx);
            this.Controls.Add(this.destCmbBx);
            this.Controls.Add(this.originCmbBx);
            this.Controls.Add(this.cnclBtn);
            this.Controls.Add(this.okBtn);
            this.Name = "LetterForm";
            this.Text = "Letter";
            this.Load += new System.EventHandler(this.LetterForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button okBtn;
        private System.Windows.Forms.Button cnclBtn;
        private System.Windows.Forms.ComboBox originCmbBx;
        private System.Windows.Forms.ComboBox destCmbBx;
        private System.Windows.Forms.TextBox costTxtBx;
        private System.Windows.Forms.Label originLbl;
        private System.Windows.Forms.Label destinationLbl;
        private System.Windows.Forms.Label costLbl;
        private System.Windows.Forms.ErrorProvider errorProvider;
    }
}