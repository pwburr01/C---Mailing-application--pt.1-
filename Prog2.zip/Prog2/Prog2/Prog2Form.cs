﻿//C7353
//CIS 200-01
//10-23-2017
//This class is for the entire system and serves as the face of the program itself.
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UPVApp
{
    public partial class Prog2Form : Form
    {
        //declared outside of constructor so that you can use it to create lists
        private UserParcelView upv;

        //precondition: none
        //postcondition: intializes program
        public Prog2Form()
        {
            InitializeComponent();

            upv = new UserParcelView();

            //populated information
            upv.AddAddress("  John Smith  ", "   123 Any St.   ", "  Apt. 45 ",
             "  Louisville   ", "  KY   ", 40202); // Test Address 1
            upv.AddAddress("Jane Doe", "987 Main St.",
                "Beverly Hills", "CA", 90210); // Test Address 2
            upv.AddAddress("James Kirk", "654 Roddenberry Way", "Suite 321",
                "El Paso", "TX", 79901); // Test Address 3
            upv.AddAddress("John Crichton", "678 Pau Place", "Apt. 7",
                "Portland", "ME", 04101); // Test Address 4
            upv.AddAddress("John Doe", "111 Market St.",
                "Jeffersonville","IN", 47130); // Test Address 5
            upv.AddAddress("Jane Smith", "55 Hollywood Blvd.", "Apt. 9",
                "Los Angeles", "CA", 90212); // Test Address 6
            upv.AddAddress("Captain Robert Crunch", "21 Cereal Rd.", "Room 987",
                "Bethesda", "MD", 20810); // Test Address 7
            upv.AddAddress("Vlad Dracula", "6543 Vampire Way", "Apt. 1",
                "Bloodsucker City", "TN", 37210); // Test Address 8



            upv.AddLetter(upv.AddressAt(0), upv.AddressAt(1), 3.95M);                            // Letter test object
            upv.AddLetter(upv.AddressAt(2), upv.AddressAt(3), 4.25M);                            // Letter test object
            upv.AddGroundPackage(upv.AddressAt(4), upv.AddressAt(5), 14, 10, 5, 12.5);        // Ground test object
            upv.AddGroundPackage(upv.AddressAt(6), upv.AddressAt(7), 8.5, 9.5, 6.5, 2.5);     // Ground test object
            upv.AddNextDayAirPackage(upv.AddressAt(0), upv.AddressAt(2), 25, 15, 15,    // Next Day test object
                85, 7.50M);
            upv.AddNextDayAirPackage(upv.AddressAt(2), upv.AddressAt(4), 9.5, 6.0, 5.5, // Next Day test object
                5.25, 5.25M);
            upv.AddNextDayAirPackage(upv.AddressAt(1), upv.AddressAt(6), 10.5, 6.5, 9.5, // Next Day test object
                15.5, 5.00M);
            upv.AddTwoDayAirPackage(upv.AddressAt(4), upv.AddressAt(6), 46.5, 39.5, 28.0, // Two Day test object
                80.5, TwoDayAirPackage.Delivery.Saver);
            upv.AddTwoDayAirPackage(upv.AddressAt(7), upv.AddressAt(0), 15.0, 9.5, 6.5,   // Two Day test object
                75.5, TwoDayAirPackage.Delivery.Early);
            upv.AddTwoDayAirPackage(upv.AddressAt(5), upv.AddressAt(3), 12.0, 12.0, 6.0,  // Two Day test object
                5.5, TwoDayAirPackage.Delivery.Saver);
        }
        //precondition: none
        //postcondition: closes out program
        private void exitMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        //precondition: none
        //postcondition: opens up about textbox
        private void abtMenuItem_Click(object sender, EventArgs e)
        {
            string NL = Environment.NewLine;

            MessageBox.Show($"Grading ID: C7353 {NL} CIS 200-01 {NL} Program 2 {NL} 10-23-2017" +
                $" {NL} Basic GUI for system we have been building this semester.");
        }
        //precondition: none
        //postcondition: opens form and allows user to create a new address
        private void addressMenuItem_Click(object sender, EventArgs e)
        {
            AddressForm addressForm = new AddressForm();

            DialogResult result = addressForm.ShowDialog(); // Show form as dialog and store result

            if (result == DialogResult.OK) // Only add if OK
            {
                if (addressForm.AddressLine2 != null)
                {
                    upv.AddAddress(addressForm.AddressName, addressForm.AddressLine1, addressForm.AddressLine2, addressForm.AddressCity, addressForm.AddressState, addressForm.AddressZip);
                }
                else
                {
                    upv.AddAddress(addressForm.AddressName, addressForm.AddressLine1, addressForm.AddressCity, addressForm.AddressState, addressForm.AddressZip);
                }
            }

            addressForm.Dispose(); 
        }
        //precondition: none
        //postcondition: displays list of addresses in the system
        private void listAddMenuItem_Click(object sender, EventArgs e)
        {
            
            displayLstBx.Items.Clear();
            displayLstBx.Items.Add("Address List:");
            displayLstBx.Items.Add("-------------------");
            foreach (Address a in upv.addresses)
            {
                if (string.IsNullOrWhiteSpace(a.Address2))
                {
                    displayLstBx.Items.Add(a.Name);
                    displayLstBx.Items.Add(a.Address1);
                    displayLstBx.Items.Add(a.City);
                    displayLstBx.Items.Add(a.State);
                    displayLstBx.Items.Add(a.Zip);
                    displayLstBx.Items.Add("-------------------");
                }
                else
                {
                    displayLstBx.Items.Add(a.Name);
                    displayLstBx.Items.Add(a.Address1);
                    displayLstBx.Items.Add(a.Address2);
                    displayLstBx.Items.Add(a.City);
                    displayLstBx.Items.Add(a.State);
                    displayLstBx.Items.Add(a.Zip);
                    displayLstBx.Items.Add("-------------------");
                }
            }

        }
        //precondition: none
        //postcondition: opens form and allows user to create a new letter
        private void letterMenuItem_Click(object sender, EventArgs e)
        {
            LetterForm letterForm = new LetterForm(upv.addresses);

            DialogResult result = letterForm.ShowDialog();

            if (result == DialogResult.OK)
            {
                upv.AddLetter(upv.AddressAt(letterForm.LetterOrigin), upv.AddressAt(letterForm.LetterDestination), letterForm.LetterCost);
            }
        }
        //precondition: none
        //postcondition: displays list of parcels in the system
        private void listParcelMenuItem_Click(object sender, EventArgs e)
        {
            displayLstBx.Items.Clear();
            displayLstBx.Items.Add("Parcel List:");
            displayLstBx.Items.Add("-------------------");
            foreach (Parcel p in upv.parcels)
            {
                displayLstBx.Items.Add("Destination Address:");
                if (string.IsNullOrWhiteSpace(p.DestinationAddress.Address2))
                {
                    displayLstBx.Items.Add(p.DestinationAddress.Name);
                    displayLstBx.Items.Add(p.DestinationAddress.Address1);
                    displayLstBx.Items.Add(p.DestinationAddress.City);
                    displayLstBx.Items.Add(p.DestinationAddress.State);
                    displayLstBx.Items.Add(p.DestinationAddress.Zip);
                }
                else
                {
                    displayLstBx.Items.Add(p.DestinationAddress.Name);
                    displayLstBx.Items.Add(p.DestinationAddress.Address1);
                    displayLstBx.Items.Add(p.DestinationAddress.Address2);
                    displayLstBx.Items.Add(p.DestinationAddress.City);
                    displayLstBx.Items.Add(p.DestinationAddress.State);
                    displayLstBx.Items.Add(p.DestinationAddress.Zip);
                }
                displayLstBx.Items.Add("");
                displayLstBx.Items.Add("Origin Address:");
                if (string.IsNullOrWhiteSpace(p.OriginAddress.Address2))
                {
                    displayLstBx.Items.Add(p.OriginAddress.Name);
                        displayLstBx.Items.Add(p.OriginAddress.Address1);
                        displayLstBx.Items.Add(p.OriginAddress.City);
                        displayLstBx.Items.Add(p.OriginAddress.State);
                        displayLstBx.Items.Add(p.OriginAddress.Zip);
                     
                    }
                    else
                    {
                        displayLstBx.Items.Add(p.OriginAddress.Name);
                        displayLstBx.Items.Add(p.OriginAddress.Address1);
                        displayLstBx.Items.Add(p.OriginAddress.Address2);
                        displayLstBx.Items.Add(p.OriginAddress.City);
                        displayLstBx.Items.Add(p.OriginAddress.State);
                        displayLstBx.Items.Add(p.OriginAddress.Zip);

                    }
                displayLstBx.Items.Add("");
                displayLstBx.Items.Add("Cost:");
                displayLstBx.Items.Add(p.CalcCost());

                displayLstBx.Items.Add("-------------------");

            }
        }
    }
}

