﻿//C7353
//CIS 200-01
//10-23-2017
//This class is for the address form and adds a new address to the system
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UPVApp
{
    public partial class AddressForm : Form
    {
        //precondition: the button is clicked to call the form
        //postcondition: the form is intialized
        public AddressForm()
        {
            InitializeComponent();

            stateCmbBx.Items.Add("KY");
            stateCmbBx.Items.Add("TN");
            stateCmbBx.Items.Add("MN");
            stateCmbBx.Items.Add("TX");
        }
        //precondition: none
        //postcondition: item is validated
        internal String AddressName
        {
            get
            {
                return nameTxtBx.Text;
            }

            set
            {
                nameTxtBx.Text = value;
            }
        }
        //precondition: none
        //postcondition: item is validated
        internal String AddressLine1
        {
            get
            {
                return address1TxtBx.Text;
            }

            set
            {
                address1TxtBx.Text = value;
            }
        }
        //precondition: none
        //postcondition: item is validated
        internal String AddressLine2
        {
            get
            {
                return address2TxtBx.Text;
            }

            set
            {
                address1TxtBx.Text = value;
            }
        }
        //precondition: none
        //postcondition: item is validated
        internal String AddressCity
        {
            get
            {
                return cityTxtBx.Text;
            }

            set
            {
                cityTxtBx.Text = value;
            }
        }
        //precondition: none
        //postcondition: item is validated
        internal String AddressState
        {
            get
            {
                return stateCmbBx.Text;
            }

            set
            {
                stateCmbBx.Text = value;
            }
        }
        //precondition: none
        //postcondition: item is validated
        internal Int32 AddressZip
        {
            get
            {
                return Convert.ToInt32(zipTxtBx.Text);
            }

            set
            {
                int zipCode;
                bool result = Int32.TryParse(zipTxtBx.Text, out zipCode);
                if (result)
                {
                    zipCode = value;
                }
                else
                {
                    zipTxtBx.SelectAll();
                    errorProvider.SetError(zipTxtBx, "Must provide a Zip Code.");
                }

            }
        }
        //precondition: none
        //postcondition: item is validated
        private void nameTxtBx_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(nameTxtBx.Text)) // Empty/whitespace field
            {
                e.Cancel = true;
                nameTxtBx.SelectAll();
                errorProvider.SetError(nameTxtBx, "Must provide name.");
            }
        }
        //precondition: none
        //postcondition: item is validated
        private void nameTxtBx_Validated(object sender, EventArgs e)
        {
            errorProvider.SetError(nameTxtBx, "");
        }
        //precondition: none
        //postcondition: item is validated
        private void addressTxtBx_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(address1TxtBx.Text)) // Empty/whitespace field
            {
                e.Cancel = true;
                address1TxtBx.SelectAll();
                errorProvider.SetError(address1TxtBx, "Must provide an address.");
            }
        }
        //precondition: none
        //postcondition: item is validated
        private void addressTxtBx_Validated(object sender, EventArgs e)
        {
            errorProvider.SetError(address1TxtBx, "");
        }
        //precondition: none
        //postcondition: item is validated
        private void cityTxtBx_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(cityTxtBx.Text)) // Empty/whitespace field
            {
                e.Cancel = true;
                cityTxtBx.SelectAll();
                errorProvider.SetError(cityTxtBx, "Must provide a city.");
            }
        }
        //precondition: none
        //postcondition: item is validated
        private void cityTxtBx_Validated(object sender, EventArgs e)
        {
            errorProvider.SetError(cityTxtBx, "");
        }
        //precondition: none
        //postcondition: item is validated
        private void zipTxtBx_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(zipTxtBx.Text))
            {
                e.Cancel = true;
                zipTxtBx.SelectAll();
                errorProvider.SetError(zipTxtBx, "Must provide a Zip Code.");
            }
          
        }
        //precondition: none
        //postcondition: item is validated
        private void zipTxtBx_Validated(object sender, EventArgs e)
        {
            errorProvider.SetError(zipTxtBx, "");
        }
        //precondition: none
        //postcondition: the form is closed and user returned to original GUI
        private void cnclBtn_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
        }
        //once everything has been validated will send an OK back to the original from so the content can be added
        private void okBtn_Click(object sender, EventArgs e)
        {
            int zipCode;
            bool result = Int32.TryParse(zipTxtBx.Text, out zipCode);
            if (result)
            {
                this.DialogResult = DialogResult.OK;
                this.Close();
            }
            else
            {
                zipTxtBx.SelectAll();
                errorProvider.SetError(zipTxtBx, "Must provide a valid Zip Code.");
            }
            
        }
    }
}
